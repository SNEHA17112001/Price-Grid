package com.example.PriceGrid.Controller;

import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.PriceGrid.Bean.PriceGrid;
import com.example.PriceGrid.RequestAndResponse.PriceGridRequest;
import com.example.PriceGrid.Service.PriceGridService;


@RestController
@RequestMapping("api")
public class PriceGridController {
	@Autowired
	PriceGridService priceservices;
	
	
	@GetMapping("/getprice")
	public ResponseEntity<HashMap<String, Object>> getFormattedPriceGrid(@RequestParam("id") Integer id) {
		HashMap<String, Object> formattedPriceGrid = priceservices.getFormattedPriceGrid(id);
		return (formattedPriceGrid != null) ? ResponseEntity.ok(formattedPriceGrid) : ResponseEntity.notFound().build();
	}
	
	@PostMapping("/saveprice")
	
	    public ResponseEntity<PriceGrid> createPriceGrid(@RequestBody PriceGridRequest priceGridRequest) {
	        PriceGrid savedPriceGrid = priceservices.savePriceGrid(priceGridRequest);
	        return ResponseEntity.ok(savedPriceGrid);
	    }
	
	
}
