package com.example.PriceGrid.Bean;

import java.io.Serializable;
import java.util.List;
import java.util.Objects;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.ElementCollection;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name = "price_grid")

public class PriceGrid implements Serializable{

@Id
@Column(name = "Id")
@GeneratedValue(strategy = GenerationType.IDENTITY)
private Integer id;

@Column(name="Widths")
private String widths;

@Column(name="Heights")
private String heights;

@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
private List<PriceRow> prices;

public PriceGrid(Integer id, String widths, String heights, List<PriceRow> prices) {
	super();
	this.id = id;
	this.widths = widths;
	this.heights = heights;
	this.prices = prices;
}

public PriceGrid() {
	super();
	// TODO Auto-generated constructor stub
}

@Override
public int hashCode() {
	return Objects.hash(heights, id, prices, widths);
}

@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	PriceGrid other = (PriceGrid) obj;
	return Objects.equals(heights, other.heights) && Objects.equals(id, other.id)
			&& Objects.equals(prices, other.prices) && Objects.equals(widths, other.widths);
}

public  Integer getId() {
	return id;
}

public  void setId(Integer id) {
	this.id = id;
}

public String getWidths() {
	return widths;
}

public  void setWidths(String widths) {
	this.widths = widths;
}

public String getHeights() {
	return heights;
}

public  void setHeights(String heights) {
	this.heights = heights;
}

public  List<PriceRow> getPrices() {
	return prices;
}

public  void setPrices(List<PriceRow> prices) {
	this.prices = prices;
}

@Override
public String toString() {
	return "PriceGrid [id=" + id + ", widths=" + widths + ", heights=" + heights + ", prices=" + prices + "]";
}


}
