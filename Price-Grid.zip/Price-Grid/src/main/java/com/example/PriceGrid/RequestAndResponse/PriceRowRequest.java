package com.example.PriceGrid.RequestAndResponse;

import java.util.List;
import java.util.Objects;

import lombok.Data;

@Data
public class PriceRowRequest {

	private Long id;
	private Integer height;
	private List<Integer> pricevalue;
	public PriceRowRequest() {
		super();
		// TODO Auto-generated constructor stub
	}
	public PriceRowRequest(Long id, Integer height, List<Integer> pricevalue) {
		super();
		this.id = id;
		this.height = height;
		this.pricevalue = pricevalue;
	}
	@Override
	public String toString() {
		return "PriceRowRequest [id=" + id + ", height=" + height + ", values=" + pricevalue + "]";
	}
	@Override
	public int hashCode() {
		return Objects.hash(height, id, pricevalue);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PriceRowRequest other = (PriceRowRequest) obj;
		return Objects.equals(height, other.height) && Objects.equals(id, other.id)
				&& Objects.equals(pricevalue, other.pricevalue);
	}
	public  Long getId() {
		return id;
	}
	public  void setId(Long id) {
		this.id = id;
	}
	public  Integer getHeight() {
		return height;
	}
	public  void setHeight(Integer height) {
		this.height = height;
	}
	public  List<Integer> getPricevalue() {
		return pricevalue;
	}
	public  void setPricevalue(List<Integer> pricevalue) {
		this.pricevalue = pricevalue;
	}
	
	
	
}
