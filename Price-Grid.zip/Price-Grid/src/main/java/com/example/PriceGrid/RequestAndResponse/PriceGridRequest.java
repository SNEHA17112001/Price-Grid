package com.example.PriceGrid.RequestAndResponse;

import java.util.List;
import java.util.Objects;

import lombok.Data;

@Data
public class PriceGridRequest {

	 private Long id;
	    private List<Integer> widths;
	    private List<Integer> heights;
	    private List<PriceRowRequest> prices;
		public PriceGridRequest() {
			super();
			// TODO Auto-generated constructor stub
		}
		public PriceGridRequest(Long id, List<Integer> widths, List<Integer> heights, List<PriceRowRequest> prices) {
			super();
			this.id = id;
			this.widths = widths;
			this.heights = heights;
			this.prices = prices;
		}
		@Override
		public String toString() {
			return "PriceGridRequest [id=" + id + ", widths=" + widths + ", heights=" + heights + ", prices=" + prices
					+ "]";
		}
		@Override
		public int hashCode() {
			return Objects.hash(heights, id, prices, widths);
		}
		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			PriceGridRequest other = (PriceGridRequest) obj;
			return Objects.equals(heights, other.heights) && Objects.equals(id, other.id)
					&& Objects.equals(prices, other.prices) && Objects.equals(widths, other.widths);
		}
		public  Long getId() {
			return id;
		}
		public  void setId(Long id) {
			this.id = id;
		}
		public  List<Integer> getWidths() {
			return widths;
		}
		public  void setWidths(List<Integer> widths) {
			this.widths = widths;
		}
		public  List<Integer> getHeights() {
			return heights;
		}
		public  void setHeights(List<Integer> heights) {
			this.heights = heights;
		}
		public  List<PriceRowRequest> getPrices() {
			return prices;
		}
		public  void setPrices(List<PriceRowRequest> prices) {
			this.prices = prices;
		}

}
