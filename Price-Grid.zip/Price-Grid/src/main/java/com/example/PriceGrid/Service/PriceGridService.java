package com.example.PriceGrid.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.PriceGrid.Bean.PriceGrid;
import com.example.PriceGrid.Bean.PriceRow;
import com.example.PriceGrid.Repository.PriceGridRepo;
import com.example.PriceGrid.RequestAndResponse.PriceGridRequest;

@Service

public class PriceGridService {

	@Autowired
	private PriceGridRepo priceGridRepository;
	
	public HashMap<String, Object> getFormattedPriceGrid(Integer id) {
		
        Optional<PriceGrid> optionalPriceGrid = priceGridRepository.findById(id);
        if (optionalPriceGrid.isPresent()) {
            PriceGrid priceGrid = optionalPriceGrid.get();
            HashMap<String, Object> response = new HashMap<>();
            
            response.put("widths", priceGrid.getWidths());
            response.put("heights", priceGrid.getHeights());

            List<HashMap<String, Object>> pricesList = new ArrayList<>();
            for (PriceRow priceRow : priceGrid.getPrices()) {
                HashMap<String, Object> priceEntry = new HashMap<>();
                priceEntry.put("height", priceRow.getHeight());
                priceEntry.put("values", priceRow.getPricevalue().toString());
                pricesList.add(priceEntry);
            }
            response.put("prices", pricesList);

            return response;
        }
        return null; 
    }

	public PriceGrid savePriceGrid(PriceGridRequest priceGridRequest) {
	    PriceGrid priceGrid = new PriceGrid();

	    try {
	    priceGrid.setWidths(priceGridRequest.getWidths().toString());
	        priceGrid.setHeights(priceGridRequest.getHeights().toString());

	        // Create PriceRow entities
	        List<PriceRow> priceRows = priceGridRequest.getPrices().stream().map(rowRequest -> {
	            PriceRow priceRow = new PriceRow();
	            priceRow.setHeight(rowRequest.getHeight());
	           
	            priceRow.setPricevalue(rowRequest.getPricevalue().toString());
	            priceRow.setPriceGrid(priceGrid); // Set the price grid reference
	            return priceRow;
	        }).toList();

	        priceGrid.setPrices(priceRows); // Set the list of price rows in the price grid

	        // Save the PriceGrid and return it
	        return priceGridRepository.save(priceGrid);
	    } catch (Exception ex) {
	        System.out.println("An exception occurred: " + ex.getMessage());
	        ex.printStackTrace();
	        return null; // Return or throw a custom error as needed
	    }
	}
}
