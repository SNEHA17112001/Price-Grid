package com.example.PriceGrid.Bean;

import java.util.List;
import java.util.Objects;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import jakarta.persistence.Column;
import jakarta.persistence.ElementCollection;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name = "price_row")

@AllArgsConstructor
@Builder
@Getter
@Setter
@NoArgsConstructor
//@AllArgsConstructor
@ToString
@DynamicInsert
@DynamicUpdate
public class PriceRow {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="id")
	private Long id;
	
	@ManyToOne
    @JoinColumn(name = "grid_id", nullable = false)
    private PriceGrid priceGrid; // Update to establish relationship


	@Column(name = "heights")
	private Integer height;

	
	@Column(name = "pricevalue") // Change the column name from `values` to `price_value`
    private String pricevalue; // Change from `values` to `priceValues`


	public PriceRow() {
		super();
		// TODO Auto-generated constructor stub
	}

	

	public PriceRow(Long id, PriceGrid priceGrid, Integer height, String pricevalue) {
		super();
		this.id = id;
		this.priceGrid = priceGrid;
		this.height = height;
		this.pricevalue = pricevalue;
	}



	@Override
	public String toString() {
		return "PriceRow [id=" + id + ", priceGrid=" + priceGrid + ", height=" + height + ", pricevalue=" + pricevalue + "]";
	}

	@Override
	public int hashCode() {
		return Objects.hash(height, id, priceGrid, pricevalue);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PriceRow other = (PriceRow) obj;
		return Objects.equals(height, other.height) && Objects.equals(id, other.id)
				&& Objects.equals(priceGrid, other.priceGrid) && Objects.equals(pricevalue, other.pricevalue);
	}

	public  Long getId() {
		return id;
	}

	public  void setId(Long id) {
		this.id = id;
	}

	public  PriceGrid getPriceGrid() {
		return priceGrid;
	}

	public  void setPriceGrid(PriceGrid priceGrid) {
		this.priceGrid = priceGrid;
	}

	public  Integer getHeight() {
		return height;
	}

	public  void setHeight(Integer height) {
		this.height = height;
	}

	public String setPricevalue() {
		return pricevalue;
	}

	public  void setPricevalue(String pricevalue) {
		this.pricevalue = pricevalue;
	}



	public  String getPricevalue() {
		return pricevalue;
	}



	
	
	
}
