package com.example.PriceGrid;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PriceGridApplicationTests {

	@Test
	void contextLoads() {
	}

}
